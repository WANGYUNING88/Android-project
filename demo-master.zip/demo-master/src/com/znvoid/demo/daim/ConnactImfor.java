package com.znvoid.demo.daim;

import java.net.Socket;

public class ConnactImfor {
	private Socket mSocket;
	
	
	
}
