package com.znvoid.demo.server;


import android.os.Handler;

public interface ISevice {

	public void setHandlerr(Handler handler);
}
