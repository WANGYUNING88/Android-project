package im.tox.antox.utils

object Options {
  var ipv6Enabled: Boolean = true

  var udpEnabled: Boolean = false

  var proxyEnabled: Boolean = false
}
