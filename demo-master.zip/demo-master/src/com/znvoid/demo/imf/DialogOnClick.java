package com.znvoid.demo.imf;

public interface DialogOnClick {

	void onClick(int event);
	
}
