package im.tox.antox.wrapper

class FriendRequest(val requestKey: String, val requestMessage: String) {

}
