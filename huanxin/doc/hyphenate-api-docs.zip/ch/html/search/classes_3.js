var searchData=
[
  ['localbinder',['LocalBinder',['../classcom_1_1hyphenate_1_1chat_1_1EMChatService_1_1LocalBinder.html',1,'com::hyphenate::chat::EMChatService']]]
];
