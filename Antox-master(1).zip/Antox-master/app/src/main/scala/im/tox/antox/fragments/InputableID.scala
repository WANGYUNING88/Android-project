package im.tox.antox.fragments

trait InputableID {
  def inputID(input: String): Unit
}