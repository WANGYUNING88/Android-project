var searchData=
[
  ['makevideocall',['makeVideoCall',['../classcom_1_1hyphenate_1_1chat_1_1EMCallManager.html#a3e49344c1ff527960e8978f2ba6858db',1,'com.hyphenate.chat.EMCallManager.makeVideoCall(String username)'],['../classcom_1_1hyphenate_1_1chat_1_1EMCallManager.html#ad87e0433c0cd3bc71c86dfaea37bd6bc',1,'com.hyphenate.chat.EMCallManager.makeVideoCall(String username, String ext)']]],
  ['makevoicecall',['makeVoiceCall',['../classcom_1_1hyphenate_1_1chat_1_1EMCallManager.html#ab18d852e3ce41debf25142b69ff04cf5',1,'com.hyphenate.chat.EMCallManager.makeVoiceCall(String username)'],['../classcom_1_1hyphenate_1_1chat_1_1EMCallManager.html#ac1865d6676dcae903ba5f8556bc1a413',1,'com.hyphenate.chat.EMCallManager.makeVoiceCall(String username, String ext)']]],
  ['markallconversationsasread',['markAllConversationsAsRead',['../classcom_1_1hyphenate_1_1chat_1_1EMChatManager.html#a4f7dbf5b36fadde636db34dfaa7fc41f',1,'com::hyphenate::chat::EMChatManager']]],
  ['markallmessagesasread',['markAllMessagesAsRead',['../classcom_1_1hyphenate_1_1chat_1_1EMConversation.html#a7b647fa38c62bb24c2469a704d3f16d5',1,'com::hyphenate::chat::EMConversation']]],
  ['markmessageasread',['markMessageAsRead',['../classcom_1_1hyphenate_1_1chat_1_1EMConversation.html#a9e542e10f41e0c7f84d9fac97d03b3fd',1,'com::hyphenate::chat::EMConversation']]],
  ['msgtype2conversationtype',['msgType2ConversationType',['../classcom_1_1hyphenate_1_1chat_1_1EMConversation.html#a2af3c651b5402f316fea84d97bf5e1eb',1,'com::hyphenate::chat::EMConversation']]],
  ['mutechatroommembers',['muteChatRoomMembers',['../classcom_1_1hyphenate_1_1chat_1_1EMChatRoomManager.html#a9085e1f9d988cccec5c8ecc7125babbf',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['mutegroupmembers',['muteGroupMembers',['../classcom_1_1hyphenate_1_1chat_1_1EMGroupManager.html#a5a3abd57e52455ae68a1a5a5039862c3',1,'com::hyphenate::chat::EMGroupManager']]]
];
