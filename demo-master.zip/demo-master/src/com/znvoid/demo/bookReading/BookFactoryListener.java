package com.znvoid.demo.bookReading;

public interface BookFactoryListener {

	void onBookProgressChange(int progress);
}
