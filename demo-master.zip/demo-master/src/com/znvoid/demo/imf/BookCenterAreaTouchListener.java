package com.znvoid.demo.imf;

public interface BookCenterAreaTouchListener {
	
	public void onAreaTouch();
	
	public void onOutSideAreaTouch();

}
