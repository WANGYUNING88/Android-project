# demo
我的第一个Android，局域网聊天

![z](z.png)

使用 appcompat design recyclerview
第三方库 imageload

功能:

![演示](hi.gif)

1.扫描局域网内设备IP及mac

2.局域网文字聊天，发送图片

3.TXT阅读
