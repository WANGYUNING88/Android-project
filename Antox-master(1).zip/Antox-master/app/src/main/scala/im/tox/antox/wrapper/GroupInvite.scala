package im.tox.antox.wrapper

class GroupInvite(val groupKey: String, val inviter: String, val data: Array[Byte]) {

}